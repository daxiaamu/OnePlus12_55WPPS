#!/system/bin/sh

ui_print "- 55W PPS for OnePlus Ace 3 Pro (test)"
[ "$BOOTMODE" = true ] || abort "! 仅支持在 Magisk App 中安装"
[ "$ARCH" = arm64 ] || abort "! 仅支持 arm64"

set_perm "$MODPATH/bin/dtbo_patch" 0 0 0755
chmod 0755 "$MODPATH/bin/dtbo_patch" 2>/dev/null || abort "! 无法设置补丁器执行权限"
set_perm "$MODPATH/patch_current.sh" 0 0 0755
set_perm "$MODPATH/check_status.sh" 0 0 0755
set_perm "$MODPATH/restore.sh" 0 0 0755
set_perm "$MODPATH/action.sh" 0 0 0755
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/uninstall.sh" 0 0 0755

ui_print "! 这是首个实机验证版"
ui_print "! 补丁会把原厂 33W UFCS 栈转换为 55W PPS，UFCS 将不可用"
ui_print "! 已保留原厂电池电压、温度、SOC、硅版本策略及恢复备份"
ui_print "! 音量+：确认并继续；音量-：取消安装"
[ -x "$(command -v getevent 2>/dev/null)" ] || abort "! 找不到 getevent，无法进行确认"

EVENT_FILE=/data/local/tmp/corvette_pps55_event_$$
rm -f "$EVENT_FILE"
START_TS="$(date +%s)"
while true; do
  NOW_TS="$(date +%s)"
  [ $((NOW_TS - START_TS)) -lt 120 ] || { rm -f "$EVENT_FILE"; abort "! 等待确认超时（2 分钟），安装已取消"; }
  rm -f "$EVENT_FILE"
  getevent -qlc 1 > "$EVENT_FILE" 2>/dev/null &
  EVENT_PID=$!
  sleep 1
  kill "$EVENT_PID" 2>/dev/null
  wait "$EVENT_PID" 2>/dev/null
  EVENT="$(cat "$EVENT_FILE" 2>/dev/null)"
  echo "$EVENT" | grep -q "KEY_VOLUMEUP.*DOWN" && break
  echo "$EVENT" | grep -q "KEY_VOLUMEDOWN.*DOWN" && abort "! 用户未确认注意事项，安装已取消"
done
rm -f "$EVENT_FILE"
ui_print "- 已确认测试风险，继续执行 DTBO patch"

sh "$MODPATH/patch_current.sh" "$MODPATH" || abort "! Patch failed; DTBO was not confirmed"
PATCH_LOG=/data/adb/corvette_pps55/last_patch.log
PATCH_STATUS="$(sed -n 's/^STATUS=//p' "$PATCH_LOG" 2>/dev/null)"
if [ "$PATCH_STATUS" = PATCHED ]; then
  STATUS_TEXT="⚠️ 已写入，等待重启生效"
  ui_print "- Status: PATCHED（已写入，必须重启生效）"
else
  STATUS_TEXT="💚 已生效，无需额外重启"
  ui_print "- Status: PATCHED（已生效，无需额外重启）"
fi
awk -v desc="Ace 3 Pro PPS 55W test (replaces UFCS) [$STATUS_TEXT]. Restore DTBO before bootloader lock." '/^description=/ { print "description=" desc; next } { print }' "$MODPATH/module.prop" > "$MODPATH/module.prop.new" && mv "$MODPATH/module.prop.new" "$MODPATH/module.prop"
ui_print "! 新写入的补丁必须重启后生效"
ui_print "! 上锁 Bootloader 前请恢复原始 DTBO"
ui_print "! 系统更新或切换槽位后请重新安装/执行补丁"
ui_print "! Bootloader 状态未预检查，底层可能拒绝写入"
