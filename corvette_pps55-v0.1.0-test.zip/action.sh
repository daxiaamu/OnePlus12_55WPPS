#!/system/bin/sh
MODDIR=${0%/*}
echo "OnePlus Ace 3 Pro PPS 55W test: patch current slot"
echo "Warning: this test patch replaces the stock 33W UFCS stack."
echo "The patch is applied to DTBO and takes effect after reboot."
sh "$MODDIR/patch_current.sh" "$MODDIR"
RESULT=$?
echo
if [ "$RESULT" = 0 ]; then
  sh "$MODDIR/check_status.sh" "$MODDIR"
  echo "Reminder: reboot to activate a newly written patch."
  echo "Before locking the bootloader, restore the original DTBO partition."
  echo "After a system update or A/B slot switch, install/apply this module again."
else
  echo "Patch failed; no successful write was confirmed."
fi
exit "$RESULT"
