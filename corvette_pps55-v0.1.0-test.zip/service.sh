#!/system/bin/sh
MODDIR=${0%/*}

# Late-start read-only probe. Refreshing the Magisk module page will show the
# current slot and patch state in the module description.
sh "$MODDIR/check_status.sh" "$MODDIR" >/dev/null 2>&1
