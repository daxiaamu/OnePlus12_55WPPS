#!/system/bin/sh
MODDIR="${1:-${0%/*}}"
STATE_DIR=/data/adb/corvette_pps55
WORK=/data/local/tmp/corvette_pps55_patch_$$
cleanup() { rm -rf "$WORK"; }
trap cleanup EXIT
die() { echo "ERROR: $*"; exit 1; }

DEVICE_ID="$(getprop ro.product.device) $(getprop ro.product.vendor.device) $(getprop ro.product.odm.device) $(getprop ro.build.product)"
case "$DEVICE_ID" in
  *PJX110*|*pjx110*|*corvette*) ;;
  *) die "Unsupported device properties: $DEVICE_ID (expected PJX110/corvette)" ;;
esac
SLOT="$(getprop ro.boot.slot_suffix)"
[ -n "$SLOT" ] || die "Cannot read current slot"
for CANDIDATE in \
  "/dev/block/by-name/dtbo${SLOT}" \
  "/dev/block/bootdevice/by-name/dtbo${SLOT}" \
  "/dev/block/platform/bootdevice/by-name/dtbo${SLOT}"; do
  [ -e "$CANDIDATE" ] && { DTBO_BLOCK="$CANDIDATE"; break; }
done
[ -n "$DTBO_BLOCK" ] || die "Current slot DTBO partition not found"
[ -f "$MODDIR/bin/dtbo_patch" ] || die "Patch tool file is missing: $MODDIR/bin/dtbo_patch"
chmod 0755 "$MODDIR/bin/dtbo_patch" 2>/dev/null || die "Cannot set executable permission on patch tool"
[ -x "$MODDIR/bin/dtbo_patch" ] || die "Patch tool is not executable: $MODDIR/bin/dtbo_patch"
mkdir -p "$WORK" "$STATE_DIR/backups" || die "Cannot create work or backup directory"
chmod 0700 "$STATE_DIR" "$STATE_DIR/backups"
echo "- Current slot: $SLOT"
echo "- Reading: $DTBO_BLOCK"
dd if="$DTBO_BLOCK" of="$WORK/current.img" bs=4M 2>/dev/null || die "DTBO read failed"
CURRENT_SHA="$(sha256sum "$WORK/current.img" | awk '{print $1}')"
"$MODDIR/bin/dtbo_patch" "$WORK/current.img" "$WORK/patched.img" > "$WORK/patch.log" 2>&1 || { cat "$WORK/patch.log"; die "DTBO validation or patch failed"; }
cat "$WORK/patch.log"
STATUS="$(sed -n 's/^STATUS=//p' "$WORK/patch.log")"
PATCHED_SHA="$(sha256sum "$WORK/patched.img" | awk '{print $1}')"
[ "$(wc -c < "$WORK/current.img")" = "$(wc -c < "$WORK/patched.img")" ] || die "Patch changed image size"
if [ "$STATUS" = ALREADY_PATCHED ]; then
  echo "- Current slot is already patched; no write needed"
  cp -f "$WORK/patch.log" "$STATE_DIR/last_patch.log"
  exit 0
fi
[ "$STATUS" = PATCHED ] || die "Unknown patcher status: $STATUS"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$STATE_DIR/backups/dtbo${SLOT}_${STAMP}_${CURRENT_SHA}.img"
cp "$WORK/current.img" "$BACKUP" || die "Original DTBO backup failed"
chmod 0600 "$BACKUP"
echo "- Writing current slot dtbo${SLOT}; do not power off"
dd if="$WORK/patched.img" of="$DTBO_BLOCK" bs=4M 2>/dev/null || die "DTBO write failed; backup: $BACKUP"
sync
dd if="$DTBO_BLOCK" of="$WORK/readback.img" bs=4M 2>/dev/null || die "DTBO readback failed; backup: $BACKUP"
READBACK_SHA="$(sha256sum "$WORK/readback.img" | awk '{print $1}')"
if [ "$READBACK_SHA" != "$PATCHED_SHA" ]; then
  echo "! Readback failed; restoring original DTBO"
  dd if="$BACKUP" of="$DTBO_BLOCK" bs=4M 2>/dev/null
  sync
  die "Restore attempted; do not reboot. Check $BACKUP"
fi
SLOT_STATE="$STATE_DIR/state${SLOT}.prop"
cat > "$SLOT_STATE" <<EOF
SLOT=$SLOT
DTBO_BLOCK=$DTBO_BLOCK
BACKUP=$BACKUP
STOCK_SHA256=$CURRENT_SHA
PATCHED_SHA256=$PATCHED_SHA
EOF
chmod 0600 "$SLOT_STATE"
cp -f "$SLOT_STATE" "$STATE_DIR/state.prop"
cp -f "$WORK/patch.log" "$STATE_DIR/last_patch.log"
echo "- Write and readback verification succeeded"
echo "- Original backup: $BACKUP"
echo "! Reboot required; restore DTBO before locking bootloader"
echo "! Re-apply after a system update or slot switch"
