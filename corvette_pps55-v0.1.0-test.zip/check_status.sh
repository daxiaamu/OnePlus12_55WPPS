#!/system/bin/sh
MODDIR="${1:-${0%/*}}"
STATE_DIR=/data/adb/corvette_pps55
TMP=/data/local/tmp/corvette_pps55_status_$$
SLOT="$(getprop ro.boot.slot_suffix)"
STATUS_TEXT="⚠️ 状态未知"
cleanup() { rm -f "$TMP.img" "$TMP.out" "$TMP.log" "$MODDIR/module.prop.new"; }
trap cleanup EXIT
for CANDIDATE in \
  "/dev/block/by-name/dtbo${SLOT}" \
  "/dev/block/bootdevice/by-name/dtbo${SLOT}" \
  "/dev/block/platform/bootdevice/by-name/dtbo${SLOT}"; do
  [ -e "$CANDIDATE" ] && { DTBO_BLOCK="$CANDIDATE"; break; }
done
if [ -n "$SLOT" ] && [ -n "$DTBO_BLOCK" ] && [ -x "$MODDIR/bin/dtbo_patch" ]; then
  if dd if="$DTBO_BLOCK" of="$TMP.img" bs=4M 2>/dev/null && "$MODDIR/bin/dtbo_patch" "$TMP.img" "$TMP.out" > "$TMP.log" 2>&1; then
    RESULT="$(sed -n 's/^STATUS=//p' "$TMP.log")"
    case "$RESULT" in
      ALREADY_PATCHED) STATUS_TEXT="💚 当前槽位 $SLOT：55W 补丁已生效" ;;
      PATCHED) STATUS_TEXT="⚠️ 当前槽位 $SLOT：尚未写入补丁，请点击 Action" ;;
      *) STATUS_TEXT="⚠️ 当前槽位 $SLOT：不兼容或状态未知" ;;
    esac
  else
    STATUS_TEXT="⚠️ 当前槽位 $SLOT：读取或校验失败"
  fi
fi
BASE="Ace 3 Pro 55W PPS DTBO test patch (replaces UFCS). Re-apply after OTA or slot switch."
awk -v desc="$BASE [$STATUS_TEXT]" '/^description=/ { print "description=" desc; next } { print }' "$MODDIR/module.prop" > "$MODDIR/module.prop.new" && mv "$MODDIR/module.prop.new" "$MODDIR/module.prop"
mkdir -p "$STATE_DIR"
echo "$STATUS_TEXT" > "$STATE_DIR/status.txt"
echo "$STATUS_TEXT"
