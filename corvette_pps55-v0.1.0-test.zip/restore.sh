#!/system/bin/sh
STATE_DIR=/data/adb/corvette_pps55
[ "$(id -u)" = 0 ] || { echo "ERROR: root required"; exit 1; }
NOW_SLOT="$(getprop ro.boot.slot_suffix)"
STATE="$STATE_DIR/state${NOW_SLOT}.prop"
[ -f "$STATE" ] || { echo "ERROR: no restore state for slot $NOW_SLOT"; exit 1; }
. "$STATE"
[ "$NOW_SLOT" = "$SLOT" ] || { echo "ERROR: backup belongs to $SLOT, current slot is $NOW_SLOT"; exit 1; }
[ -e "$DTBO_BLOCK" ] || { echo "ERROR: DTBO partition not found: $DTBO_BLOCK"; exit 1; }
[ -f "$BACKUP" ] || { echo "ERROR: backup not found: $BACKUP"; exit 1; }

TMP=/data/local/tmp/corvette_pps55_restore_$$.img
trap 'rm -f "$TMP"' EXIT
dd if="$DTBO_BLOCK" of="$TMP" bs=4M 2>/dev/null || exit 1
CURRENT_SHA="$(sha256sum "$TMP" | awk '{print $1}')"
[ "$CURRENT_SHA" = "$PATCHED_SHA256" ] || {
  echo "ERROR: current DTBO differs from this module's patched image; refusing blind overwrite."
  echo "current=$CURRENT_SHA"
  echo "expected=$PATCHED_SHA256"
  exit 1
}
[ "$(sha256sum "$BACKUP" | awk '{print $1}')" = "$STOCK_SHA256" ] || { echo "ERROR: backup hash mismatch"; exit 1; }
echo "Restoring $BACKUP -> $DTBO_BLOCK"
dd if="$BACKUP" of="$DTBO_BLOCK" bs=4M 2>/dev/null || exit 1
sync
dd if="$DTBO_BLOCK" of="$TMP" bs=4M 2>/dev/null || exit 1
[ "$(sha256sum "$TMP" | awk '{print $1}')" = "$STOCK_SHA256" ] || { echo "ERROR: restore readback failed; do not reboot"; exit 1; }
mv "$STATE" "$STATE.restored"
echo "Restore and readback verification succeeded."
echo "You may now lock the bootloader or install a system update."
