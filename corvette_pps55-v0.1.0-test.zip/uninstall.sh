#!/system/bin/sh
MODDIR=${0%/*}
STATE_DIR=/data/adb/corvette_pps55
NOW_SLOT="$(getprop ro.boot.slot_suffix)"

# Restore only the active slot and only if every hash guard succeeds. Backups
# for both slots intentionally remain in STATE_DIR after module removal.
if [ -f "$STATE_DIR/state${NOW_SLOT}.prop" ]; then
  sh "$MODDIR/restore.sh" >> "$STATE_DIR/uninstall.log" 2>&1 || true
fi
